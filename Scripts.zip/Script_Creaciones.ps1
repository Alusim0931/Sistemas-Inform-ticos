﻿$clave=ConvertTo-SecureString "finiquito88" -AsPlainText -Force
New-LocalUser -Name "Luis" -FullName "Luis Lozano" -Password $clave -Description "Alumno de 1ESO" 
$clave=ConvertTo-SecureString "finiquito88" -AsPlainText -Force
New-LocalUser -Name "Pere"-FullName "Pere Quilombo" -Password $clave -Description "Alumno de 2ESO"
$clave=ConvertTo-SecureString "finiquito88" -AsPlainText -Force
New-LocalUser -Name "Miguel"-FullName "Miguel Peris" -Password $clave -Description "Alumno de 3ESO"
$clave=ConvertTo-SecureString "finiquito88" -AsPlainText -Force
New-LocalUser -Name "Pedro"-FullName "Pedro Soldado" -Password $clave -Description "Alumno de 4ESO"
$clave=ConvertTo-SecureString "finiquito88" -AsPlainText -Force
New-LocalUser -Name "Jorge"-FullName "Jorge Martinez" -Password $clave -Description "Alumno de 1BACH" 
$clave=ConvertTo-SecureString "finiquito88" -AsPlainText -Force
New-LocalUser -Name "Raul"-FullName "Raul Federado" -Password $clave -Description "Alumno de 2BACH" 
$clave=ConvertTo-SecureString "finiquito88" -AsPlainText -Force
New-LocalUser -Name "Evaristo"-FullName "Evaristo Gutierrez" -Password $clave -Description "Alumno DAM" 
$clave=ConvertTo-SecureString "finiquito88" -AsPlainText -Force
New-LocalUser -Name "Alumno"-FullName "Alumno" -Password $clave -Description "Alumno que no tiene cuenta" 
$clave=ConvertTo-SecureString "finiquito88" -AsPlainText -Force5
New-LocalUser -Name "Profesor"-FullName "Profesor" -Password $clave -Description "Profesorado"

New-LocalGroup -Name Alumnos1ESO -Description "Grupos para los alumnos de 1ESO"
New-LocalGroup -Name Alumnos2ESO -Description "Grupos para los alumnos de 2ESO"
New-LocalGroup -Name Alumnos3ESO -Description "Grupos para los alumnos de 3ESO"
New-LocalGroup -Name Alumnos4ESO -Description "Grupos para los alumnos de 4ESO"
New-LocalGroup -Name Alumnos1BACH -Description "Grupos para los alumnos de 1BACH"
New-LocalGroup -Name Alumnos2BACH -Description "Grupos para los alumnos de 2BACH"
New-LocalGroup -Name AlumnosDAM -Description "Grupoo para los alumnos de DAM"
New-LocalGroup -Name Alumnos -Description "Grupo para los alumnos sin cuenta"
New-LocalGroup -Name Profesores -Description "Grupo para el profesorado"

net localgroup usuarios Luis /add
net localgroup Alumnos1ESO Luis /add
net localgroup usuarios Pere /add
net localgroup Alumnos2ESO Pere /add
net localgroup usuarios Miguel /add
net localgroup Alumnos3ESO Miguel /add
net localgroup usuarios Pedro /add
net localgroup Alumnos4ESO Pedro /add
net localgroup usuarios Jorge /add
net localgroup Alumnos1BACH Jorge /add
net localgroup usuarios Raul /add
net localgroup Alumnos2BACH Raul /add
net localgroup usuarios Evaristo /add
net localgroup AlumnosDAM Evaristo /add
net localgroup Administradores Evaristo /add
net localgroup usuarios Alumno /add
net localgroup Alumnos Alumno /add
net localgroup usuarios Profesor /add
net localgroup Profesores Profesor /add

New-LocalGroup -Name Publico_RX  -Description "RX Publico"
New-LocalGroup -Name Publico_RWX  -Description "RWX Publico"
New-LocalGroup -Name ESO_RX  -Description "RX ESO"
New-LocalGroup -Name ESO1_RWX  -Description "RWX 1ESO"
New-LocalGroup -Name ESO2_RWX  -Description "RWX 2ESO"
New-LocalGroup -Name ESO3_RWX  -Description "RWX 3ESO"
New-LocalGroup -Name ESO4_RWX  -Description "RWX 4ESO"
New-LocalGroup -Name BACH_RX  -Description "RX BACH"
New-LocalGroup -Name BACH1_RWX  -Description "RWX 1BACH"
New-LocalGroup -Name BACH2_RWX  -Description "RWX 2BACH"
New-LocalGroup -Name DAM_RWX  -Description "RWX DAM"

net localgroup Publico_RWX Evaristo /add
net localgroup Publico_RX Luis /add
net localgroup Publico_RX Pere /add
net localgroup Publico_RX Miguel /add
net localgroup Publico_RX Pedro /add
net localgroup Publico_RX Jorge /add
net localgroup Publico_RX Raul /add
net localgroup ESO_RX Luis /add
net localgroup ESO_RX Pere /add
net localgroup ESO_RX Miguel /add
net localgroup ESO_RX Pedro /add
net localgroup ESO1_RWX Luis /add
net localgroup ESO2_RWX Pere /add
net localgroup ESO3_RWX Miguel /add
net localgroup ESO4_RWX Pedro /add
net localgroup BACH_RX Jorge /add
net localgroup BACH_RX Raul /add
net localgroup BACH1_RWX Jorge /add
net localgroup BACH2_RWX Raul /add
net localgroup DAM_RWX Evaristo /add

net user Evaristo /times:L-D,3pm-9pm
net user Raul /times:L-D,08:00-23:00
net user Jorge /times:L-D,08:00-23:00
net user Alumno /times:L-D,08:00-09:00
net user Profesor /times:L-D,08:00-09:00
net user Pedro /times:L-D,10:00-23:00
net user Miguel /times:L-V,11:00-12:00
net user Pere /times:L-V,09:00-10:00
net user Luis /times:L-D,08:00-09:00