﻿icacls "C:\Proyecto" /inheritance:d /T 
icacls "C:\Proyecto" /remove:g Usuarios 
icacls "C:\Proyecto" /remove:g "Usuarios autentificados" 
icacls "C:\Proyecto\1Eso" /inheritance:d /T 
icacls "C:\Proyecto\1Eso" /remove:g Usuarios 
icacls "C:\Proyecto\1Eso" /remove:g "Usuarios autentificados" 
icacls "C:\Proyecto\2Eso" /inheritance:d /T 
icacls "C:\Proyecto\2Eso" /remove:g Usuarios 
icacls "C:\Proyecto\2Eso" /remove:g "Usuarios autentificados" 
icacls "C:\Proyecto\3Eso" /inheritance:d /T 
icacls "C:\Proyecto\3Eso" /remove:g Usuarios 
icacls "C:\Proyecto\3Eso" /remove:g "Usuarios autentificados" 
icacls "C:\Proyecto\4Eso" /inheritance:d /T 
icacls "C:\Proyecto\4Eso" /remove:g Usuarios 
icacls "C:\Proyecto\4Eso" /remove:g "Usuarios autentificados" 
icacls "C:\Proyecto\1Bach" /remove:g "Usuarios autentificados" 
icacls "C:\Proyecto\1Bach" /inheritance:d /T 
icacls "C:\Proyecto\1Bach" /remove:g Usuarios 
icacls "C:\Proyecto\2Bach" /remove:g "Usuarios autentificados" 
icacls "C:\Proyecto\2Bach" /inheritance:d /T 
icacls "C:\Proyecto\2Bach" /remove:g Usuarios 
icacls "C:\Proyecto\Dam" /inheritance:d /T 
icacls "C:\Proyecto\Dam" /remove:g Usuarios 
icacls "C:\Proyecto\Dam" /remove:g "Usuarios autentificados" 
icacls "C:\Proyecto" /grant Publico_RWX:(OI)(M) 
icacls "C:\Proyecto" /grant Publico_RX:(OI)(RX) 
icacls "C:\Proyecto\1Eso" /grant ESO_RX:(OI)(RX) 
icacls "C:\Proyecto\2Eso" /grant ESO_RX:(OI)(RX) 
icacls "C:\Proyecto\3Eso" /grant ESO_RX:(OI)(RX) 
icacls "C:\Proyecto\4Eso" /grant ESO_RX:(OI)(RX) 
icacls "C:\Proyecto\1Bach" /grant BACH_RX:(OI)(CI)(RX) 
icacls "C:\Proyecto\2Bach" /grant BACH_RX:(OI)(CI)(RX) 
icacls "C:\Proyecto\Dam" /grant DAM_RWX:(OI)(CI)(M) 
icacls "C:\Proyecto\1Eso" /grant ESO1_RWX:(OI)(CI)(M) 
icacls "C:\Proyecto\2Eso" /grant ESO2_RWX:(OI)(CI)(M) 
icacls "C:\Proyecto\3Eso" /grant ESO3_RWX:(OI)(CI)(M) 
icacls "C:\Proyecto\4Eso" /grant ESO4_RWX:(OI)(CI)(M) 
icacls "C:\Proyecto\1Bach" /grant BACH1_RWX:(OI)(CI)(M) 
icacls "C:\Proyecto\2Bach" /grant BACH2_RWX:(OI)(CI)(M) 